#!/bin/bash

rosservice call /gazebo/reset_simulation