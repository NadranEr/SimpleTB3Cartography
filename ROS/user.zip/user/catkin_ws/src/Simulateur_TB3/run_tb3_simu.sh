#!/bin/bash

roslaunch turtlebot3_gazebo turtlebot3_empty_world.launch